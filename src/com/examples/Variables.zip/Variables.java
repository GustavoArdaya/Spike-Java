package com.examples;

public class Variables {
    //estos son los tipos primitivos:

    //Numéricos:
    byte unSoloByte = 1;
    short dosBytes = 2;
    int entero = 60; // 4 bytes
    long numeroGrande = 109238710; // 8 bytes, como el nintendo!

    // Numeros decimales

    float decimalFlotante = 10.5f;

    double decimalGrande = 40.0006d;

    // Caracteres y strings:

    char unaSolaLetra = 'g'; // al parecer las comillas son simples!

    String cuerdaDeCaracteres = "Este si puede ir con doble comilla, parece";

    // Booleanos:

    boolean srVerdad = true;
    boolean srMentira = false;

    // Los tipo "envoltorio" (Muy interesantes!)

    Integer numeroVacio;
    Long granNumeroEnteroVacio;




}
